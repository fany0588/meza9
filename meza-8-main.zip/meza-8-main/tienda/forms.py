from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Usuario, Producto, Resena

class RegistroForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True, label='Nombre')
    last_name = forms.CharField(max_length=30, required=True, label='Apellido')
    telefono = forms.CharField(max_length=15, required=True)
    calle = forms.CharField(max_length=100, required=True)
    numero_casa = forms.CharField(max_length=10, required=True)
    colonia = forms.CharField(max_length=100, required=True)
    ciudad = forms.CharField(max_length=100, required=True)
    codigo_postal = forms.CharField(max_length=10, required=True)
    descripcion_direccion = forms.CharField(widget=forms.Textarea, required=False)
    
    class Meta:
        model = Usuario
        fields = ('username', 'email', 'first_name', 'last_name', 'password1', 'password2',
                 'telefono', 'calle', 'numero_casa', 'colonia', 'ciudad', 
                 'codigo_postal', 'descripcion_direccion')
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.telefono = self.cleaned_data['telefono']
        user.calle = self.cleaned_data['calle']
        user.numero_casa = self.cleaned_data['numero_casa']
        user.colonia = self.cleaned_data['colonia']
        user.ciudad = self.cleaned_data['ciudad']
        user.codigo_postal = self.cleaned_data['codigo_postal']
        user.descripcion_direccion = self.cleaned_data['descripcion_direccion']
        
        if commit:
            user.save()
        return user

class PerfilForm(forms.ModelForm):
    first_name = forms.CharField(max_length=30, required=True, label='Nombre')
    last_name = forms.CharField(max_length=30, required=True, label='Apellido')
    email = forms.EmailField(required=True, label='Correo electrónico')
    telefono = forms.CharField(max_length=15, required=True, label='Teléfono')
    calle = forms.CharField(max_length=100, required=True, label='Calle')
    numero_casa = forms.CharField(max_length=10, required=True, label='Número')
    colonia = forms.CharField(max_length=100, required=True, label='Colonia')
    ciudad = forms.CharField(max_length=100, required=True, label='Ciudad')
    codigo_postal = forms.CharField(max_length=10, required=True, label='Código Postal')
    descripcion_direccion = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3}), 
        required=False, 
        label='Referencias'
    )
    metodo_pago = forms.CharField(max_length=50, required=False, label='Método de Pago Preferido')
    
    class Meta:
        model = Usuario
        fields = [
            'first_name', 
            'last_name', 
            'email', 
            'telefono',
            'calle',
            'numero_casa', 
            'colonia',
            'ciudad',
            'codigo_postal',
            'descripcion_direccion',
            'metodo_pago'
        ]

class ProductoForm(forms.ModelForm):
    edad_recomendada = forms.CharField(
        max_length=20, 
        required=False, 
        label='Edad Recomendada',
        help_text='Ej: 3-6 meses, 2-4 años, etc.'
    )
    
    class Meta:
        model = Producto
        fields = '__all__'
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 4, 'placeholder': 'Describe el producto...'}),
            'nombre': forms.TextInput(attrs={'placeholder': 'Nombre del producto...'}),
            'precio': forms.NumberInput(attrs={'step': '0.01', 'min': '0'}),
            'stock': forms.NumberInput(attrs={'min': '0'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Mejorar la apariencia de los campos
        for field_name, field in self.fields.items():
            if isinstance(field, forms.CharField) and not isinstance(field, forms.ChoiceField):
                field.widget.attrs.update({'class': 'form-control'})
            elif isinstance(field, forms.ChoiceField):
                field.widget.attrs.update({'class': 'form-select'})
            elif isinstance(field, forms.NumberInput):
                field.widget.attrs.update({'class': 'form-control'})
            elif isinstance(field, forms.Textarea):
                field.widget.attrs.update({'class': 'form-control'})

class ResenaForm(forms.ModelForm):
    class Meta:
        model = Resena
        fields = ('calificacion', 'comentario', 'foto_producto')
        widgets = {
            'calificacion': forms.NumberInput(attrs={'min': 1, 'max': 5, 'class': 'form-control'}),
            'comentario': forms.Textarea(attrs={'rows': 4, 'class': 'form-control', 'placeholder': 'Escribe tu reseña...'}),
        }
        labels = {
            'calificacion': 'Calificación (1-5 estrellas)',
            'comentario': 'Comentario',
            'foto_producto': 'Foto del producto (opcional)'
        }